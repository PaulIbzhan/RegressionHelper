library(testthat)
library(RegressionHelper)

data(mtcars)

test_that("multiple_linear_regression works", {
  model <- multiple_linear_regression(mpg ~ wt + hp, data = mtcars)
  
  expect_s3_class(model, "lm")
  expect_gte(length(coef(model)), 2)
})
