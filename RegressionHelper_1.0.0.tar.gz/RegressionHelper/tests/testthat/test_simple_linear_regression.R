library(testthat)
library(RegressionHelper)

data(mtcars)

test_that("simple_linear_regression works", {
  model <- simple_linear_regression(mpg ~ wt, data = mtcars)
  
  expect_s3_class(model, "lm")
  expect_type(coef(model), "double")
  expect_gt(length(residuals(model)), 0)
})
