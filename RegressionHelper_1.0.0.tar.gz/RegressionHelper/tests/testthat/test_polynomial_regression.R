library(testthat)
library(RegressionHelper)

data(mtcars)

test_that("polynomial_regression works", {
  model <- polynomial_regression(mpg ~ wt, data = mtcars, degree = 2)
  
  expect_s3_class(model, "lm")
  expect_gte(length(coef(model)), 3)
})
