test_that('glm_regression works', {
  model <- glm_regression(vs ~ wt, mtcars, family = binomial())
  expect_s3_class(model, 'glm')
})
