simple_linear_regression <- function(formula, data) {
  if (!inherits(data, "data.frame")) {
    stop("Error: The provided data must be a data frame.")
  }
  
  if (!inherits(formula, "formula")) {
    stop("Error: The formula must be of type 'formula'. Example: mpg ~ wt")
  }
  
  message("Fitting Simple Linear Regression Model...")
  
  model <- tryCatch({
    lm(formula, data)
  }, error = function(e) {
    stop("Error: Unable to fit the model. Check your formula and data structure.")
  })
  
  message("Simple Linear Regression Model successfully fitted.")
  return(model)
}
