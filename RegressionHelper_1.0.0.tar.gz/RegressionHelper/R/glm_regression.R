glm_regression <- function(formula, data, family = gaussian) {
  if (!inherits(data, "data.frame")) {
    stop("Error: The provided data must be a data frame.")
  }
  
  if (!inherits(formula, "formula")) {
    stop("Error: The formula must be of type 'formula'. Example: vs ~ wt + hp")
  }
  
  if (!inherits(family, "family")) {
    stop("Error: The family argument must be a valid distribution family. Example: binomial()")
  }
  
  message("Fitting Generalized Linear Model...")
  
  model <- tryCatch({
    glm(formula, data, family = family)
  }, error = function(e) {
    stop("Error: GLM fitting failed. Verify input parameters.")
  })
  
  message("Generalized Linear Model successfully fitted.")
  return(model)
}
