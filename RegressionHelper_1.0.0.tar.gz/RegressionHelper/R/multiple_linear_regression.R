multiple_linear_regression <- function(formula, data) {
  if (!inherits(data, "data.frame")) {
    stop("Error: The provided data must be a data frame.")
  }
  
  if (!inherits(formula, "formula")) {
    stop("Error: The formula must be of type 'formula'. Example: mpg ~ wt + hp")
  }
  
  message("Fitting Multiple Linear Regression Model...")
  
  model <- tryCatch({
    lm(formula, data)
  }, error = function(e) {
    stop("Error: Unable to fit the model. Ensure data is structured correctly.")
  })
  
  message("Multiple Linear Regression Model successfully fitted.")
  return(model)
}
