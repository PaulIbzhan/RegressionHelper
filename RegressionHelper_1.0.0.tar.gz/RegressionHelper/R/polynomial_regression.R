polynomial_regression <- function(formula, data, degree = 2) {
  if (!inherits(data, "data.frame")) {
    stop("Error: The provided data must be a data frame.")
  }
  
  if (!inherits(formula, "formula")) {
    stop("Error: The formula must be of type 'formula'. Example: mpg ~ wt")
  }
  
  if (!is.numeric(degree) || degree < 1) {
    stop("Error: Degree must be a positive integer.")
  }
  
  message("Creating polynomial terms for regression...")
  
  terms <- all.vars(formula)[2]
  poly_formula <- as.formula(paste0(all.vars(formula)[1], " ~ poly(", terms, ", ", degree, ")"))
  
  model <- tryCatch({
    lm(poly_formula, data)
  }, error = function(e) {
    stop("Error: Unable to fit the polynomial regression model.")
  })
  
  message("Polynomial Regression Model successfully fitted.")
  return(model)
}
